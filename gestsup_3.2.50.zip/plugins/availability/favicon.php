<?php
################################################################################
# @Name : /plugins/availability/favicon.php
# @Description : display favicon of current plugin
# @Call : /plugin.php
# @Parameters : 
# @Author : Flox
# @Create : 22/01/2021
# @Update : 15/02/2021
# @Version : 3.2.9
################################################################################

if($_GET['page']=='plugins/availability/availability') {$favicon='plugins/availability/images/favicon_availability.png';} 
?>