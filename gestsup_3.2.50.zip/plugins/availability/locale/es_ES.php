<?php
	define("_lang_access_error", "No tiene derechos de acceso a esta sección, comuníquese con su administrador");
	define("_lang_it_availability", "Disponibilidad del sistema de información");
?>