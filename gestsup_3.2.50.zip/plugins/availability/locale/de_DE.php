<?php
	define("_lang_access_error", "Sie haben keine Zugriffsrechte auf diesen Abschnitt. Wenden Sie sich an Ihren Administrator");
	define("_lang_it_availability", "Verfügbarkeit des Informationssystems");
?>