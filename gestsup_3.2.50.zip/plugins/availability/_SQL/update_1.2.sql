SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET default_storage_engine=INNODB;

UPDATE `tplugins` SET `version`='1.2' WHERE name='availability';