SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET default_storage_engine=INNODB;

INSERT INTO `tplugins` (`name`, `label`, `description`, `icon`, `version`) VALUES ('availability','Disponibilité','Active le suivi des catégories afin de produire des statistiques de disponibilité','clock','1.0');