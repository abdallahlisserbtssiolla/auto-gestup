<?php
################################################################################
# @Name : /plugins/availability/page_white_list.php
# @Description : allow page to be display
# @Call : /plugin.php
# @Parameters : 
# @Author : Flox
# @Create : 22/01/2021
# @Update : 15/02/2021
# @Version : 3.2.9
################################################################################

array_push($page_white_list,'plugins/availability/availability');
?>