locales for gestsup, to create new langage download poedit from https://poedit.net/, create this directories:

/locale
   /en_US
      /LC_MESSAGES
         /en_US.po
         /en_US.mo
/locale
   /es_ES
      /LC_MESSAGES
         /es_ES.po
         /es_ES.mo

For full application integration, please post your file on https://gestsup.fr/forum/